import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import helper
import numpy as np
import pandas as pd
import os
import json
from datetime import datetime

def main():
    # Create necessary directories
    os.makedirs('./img', exist_ok=True)
    os.makedirs('./results', exist_ok=True)

    # 1. Load and prepare data
    print("Loading and splitting data...")
    # train_df, valid_df, test_df = helper.load_and_split_data('./data/train.csv', './data/test.csv')
    train_df = pd.read_csv('./data/train.csv')
    test_df = pd.read_csv('./data/test.csv')

    print(f"Train data shape: {train_df.shape}")
    # print(f"Validation data shape: {valid_df.shape}")
    print(f"Test data shape: {test_df.shape}")

    # 2. Analyze training data distribution
    print("\nAnalyzing rating distribution...")
    helper.plot_rating_distribution(train_df, './img/rating_distribution.png')

    # 3. Create user-item matrices
    print("\nCreating user-item matrices...")
    train_matrix = helper.create_user_item_matrix(train_df)

    # # 4. Define parameter grid
    # param_grid = {
    #     'K': [10, 20, 30],
    #     'alpha': [0.001, 0.01, 0.02],
    #     'beta': [0.01],
    #     'iterations': [50, 100],
    #     'batch_size': [2000],
    #     'early_stopping_rounds': [3],
    #     'min_improvement': [0.001]
    # }

    # # 5. Perform grid search
    # best_params, results = helper.grid_search(train_matrix, valid_df, param_grid)

    best_params = {
        "K": 30,
        "alpha": 0.001,
        "beta": 0.01,
        "iterations": 100,
        "batch_size": 2000,
        "early_stopping_rounds": 3,
        "min_improvement": 0.001,
    }
    
    # # 6. Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    # results_file = f'./results/grid_search_results_{timestamp}.json'
    # with open(results_file, 'w') as f:
    #     json.dump({
    #         'best_params': best_params,
    #         'all_results': results
    #     }, f, indent=4)
    # print(f"\nSaved grid search results to {results_file}")

    # # 7. Plot parameter comparisons
    # print("\nPlotting parameter comparisons...")
    # helper.plot_parameter_comparison(results, './img')

    # 8. Train final model with best parameters
    print("\nTraining final model with best parameters...")
    P, Q, bu, bi, global_mean, training_errors = helper.matrix_factorization(
        train_matrix.values,
        **best_params
    )

    # 9. Plot final training error
    print("\nPlotting training error...")
    helper.plot_training_error(training_errors, './img/final_training_error.png')

    # 10. Make predictions on test set
    print("\nMaking predictions on test set...")
    test_predictions = []
    test_user_book_pairs = []
    
    for idx, row in test_df.iterrows():
        if row['user_id'] in train_matrix.index and row['book_id'] in train_matrix.columns:
            user_idx = train_matrix.index.get_loc(row['user_id'])
            item_idx = train_matrix.columns.get_loc(row['book_id'])
            
            pred = helper.predict_rating(
                P[user_idx], 
                Q[item_idx].reshape(1, -1), 
                bu[user_idx], 
                bi[item_idx], 
                global_mean
            )
            test_predictions.append(pred[0])
            test_user_book_pairs.append((row['user_id'], row['book_id']))

    # 12. Create submission dataframe
    submission_df = pd.DataFrame({
        'id': [i for i in range(len(test_predictions))],
        'rating': test_predictions
    })
    
    # Save predictions
    predictions_file = f'predictions_{timestamp}.csv'
    submission_df.to_csv(predictions_file, index=False)
    print(f"\nSaved test predictions to {predictions_file}")

if __name__ == "__main__":
    main()
